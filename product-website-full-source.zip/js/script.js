let products = JSON.parse(localStorage.getItem("products")) || [
 {name:"Áo thun nam",price:150000,image:"https://via.placeholder.com/200"},
 {name:"Giày thể thao",price:450000,image:"https://via.placeholder.com/200"}
];
function save(){localStorage.setItem("products",JSON.stringify(products));}
function show(){
 let list=document.getElementById("product-list");
 if(!list)return;
 list.innerHTML="";
 products.forEach(p=>{
  list.innerHTML+=`<div class='product'>
  <img src='${p.image}'><h3>${p.name}</h3>
  <p>${p.price.toLocaleString()} VNĐ</p></div>`;
 });
}
function admin(){
 let a=document.getElementById("admin-list");
 if(!a)return;
 a.innerHTML="";
 products.forEach((p,i)=>{
  a.innerHTML+=`<div class='product'>
  <h3>${p.name}</h3><p>${p.price.toLocaleString()} VNĐ</p>
  <button onclick='del(${i})'>Xóa</button></div>`;
 });
}
function del(i){products.splice(i,1);save();show();admin();}
let f=document.getElementById("product-form");
if(f){
 f.addEventListener("submit",e=>{
  e.preventDefault();
  products.push({
   name:name.value,
   price:Number(price.value),
   image:image.value||"https://via.placeholder.com/200"
  });
  save();admin();f.reset();
 });
}
show();admin();
